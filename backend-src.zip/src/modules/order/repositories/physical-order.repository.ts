import { supabase, assertNoError, assertNoErrorMany } from '@/config/database'
import type {
  OrderItemPhysical,
  OrderItemPhysicalListEntry,
  OrderPartySummary,
  OrderTimelineEvent,
  DeliveryProof,
  OrderInvoice,
  OrderReceipt,
  RefundRequest,
  PhysicalOrderView,
  PhysicalOrderFilters,
  TimelineStatus,
  DeliveryStatus,
  RefundStatus,
  CourierServiceType,
  OrderStatus,
  TransactionStatus,
} from '@/common/types/commerce.types'
import type { Order, OrderItem } from '@/common/types/commerce.types'
import { toOrderItem } from './order.repository'

// ── Row → Domain mappers ──────────────────────────────────────────────────────

function toPhysical(row: any): OrderItemPhysical {
  return {
    id:                       row['id'],
    order_item_id:            row['order_item_id'],
    order_id:                 row['order_id'],
    timeline_status:          row['timeline_status'] as TimelineStatus,
    delivery_status:          row['delivery_status'] as DeliveryStatus,
    shipping_cost:            row['shipping_cost'] != null ? Number(row['shipping_cost']) : null,
    courier_name:             row['courier_name'] ?? null,
    courier_service_type:     (row['courier_service_type'] ?? null) as CourierServiceType | null,
    tracking_id:              row['tracking_id'] ?? null,
    estimated_delivery_date:  row['estimated_delivery_date'] ? new Date(row['estimated_delivery_date']) : null,
    pickup_address:           row['pickup_address'] ?? null,
    refund_status:            row['refund_status'] as RefundStatus,
    refund_amount:            row['refund_amount'] != null ? Number(row['refund_amount']) : null,
    refund_initiated_at:      row['refund_initiated_at'] ? new Date(row['refund_initiated_at']) : null,
    refund_completed_at:      row['refund_completed_at'] ? new Date(row['refund_completed_at']) : null,
    refund_notes:             row['refund_notes'] ?? null,
    confirmed_at:             row['confirmed_at'] ? new Date(row['confirmed_at']) : null,
    picked_up_at:             row['picked_up_at'] ? new Date(row['picked_up_at']) : null,
    in_transit_at:            row['in_transit_at'] ? new Date(row['in_transit_at']) : null,
    delivered_at:             row['delivered_at'] ? new Date(row['delivered_at']) : null,
    created_at:               new Date(row['created_at']),
    updated_at:               new Date(row['updated_at']),
  }
}

// Joins order_items (product snapshot — already denormalized at checkout, so
// no separate artworks lookup is needed) and the buyer/seller's public
// profile. Used by list endpoints only; single-item detail views go through
// getOrderView, which has its own richer assembly.
//
// NOTE: `profile:profiles` is embedded off `users` with no explicit fkey
// hint (relies on PostgREST inferring the single profiles.user_id relation),
// matching the pattern used elsewhere in this codebase (see artwork
// repository's CREATOR_EMBED). `username` is read from the profile embed,
// not from `users` directly — per the schema in 001_initial_schema.sql,
// `users` has no `username` column; only `profiles.username` does.
const PHYSICAL_LIST_EMBED = `
  *,
  order_item:order_items!order_item_physical_order_item_id_fkey (
    artwork_id,
    artwork_title,
    artwork_slug,
    artwork_thumbnail_url,
    artwork_format,
    unit_price,
    quantity,
    created_at,
    seller:users!order_items_seller_id_fkey (
      id,
      profile:profiles ( username, display_name, avatar_url )
    )
  ),
  order:orders!order_item_physical_order_id_fkey (
    order_number,
    buyer:users!orders_buyer_id_fkey (
      id,
      profile:profiles ( username, display_name, avatar_url )
    )
  )
`

function toPartySummary(userRow: any): OrderPartySummary | null {
  if (!userRow) return null
  const profile = Array.isArray(userRow.profile) ? (userRow.profile[0] ?? null) : (userRow.profile ?? null)
  return {
    id:           userRow.id,
    username:     profile?.username ?? null,
    display_name: profile?.display_name ?? null,
    avatar_url:   profile?.avatar_url ?? null,
  }
}

function toPhysicalListEntry(row: any): OrderItemPhysicalListEntry {
  const orderItem = Array.isArray(row.order_item) ? row.order_item[0] : row.order_item
  const order     = Array.isArray(row.order)      ? row.order[0]      : row.order

  return {
    ...toPhysical(row),
    order_number: order?.order_number ?? null,
    order_item: {
      artwork_id:            orderItem?.artwork_id ?? '',
      artwork_title:         orderItem?.artwork_title ?? 'Untitled artwork',
      artwork_slug:          orderItem?.artwork_slug ?? '',
      artwork_thumbnail_url: orderItem?.artwork_thumbnail_url ?? null,
      artwork_format:        orderItem?.artwork_format ?? 'PHYSICAL',
      unit_price:            orderItem?.unit_price != null ? Number(orderItem.unit_price) : 0,
      quantity:              orderItem?.quantity ?? 1,
      created_at:            new Date(orderItem?.created_at ?? row['created_at']),
    },
    cancelled_by: null,
    cancelled_at: null,
    buyer:  toPartySummary(order?.buyer),
    seller: toPartySummary(orderItem?.seller),
    source:         'physical',
    order_status:   null,
    payment_status: null,
  }
}

// ── Unfulfilled entries ──────────────────────────────────────────────────────
// A physical order item that has no order_item_physical row yet (payment pending,
// failed, expired, or cancelled before payment) is still a physical order. These
// helpers build its list entry so the buyer sees it like any other physical order.

type UnfulfilledOrderRow = {
  id:           string
  order_number: string | null
  status:       OrderStatus
  cancelled_by: OrderTimelineEvent['actor_role'] | null
  cancelled_at: string | null
  updated_at:   string
}

const UNFULFILLED_ORDER_COLUMNS = 'id, order_number, status, buyer_id, cancelled_by, cancelled_at, updated_at'

const UNFULFILLED_ITEM_COLUMNS = `
  id,
  order_id,
  artwork_id,
  artwork_title,
  artwork_slug,
  artwork_thumbnail_url,
  artwork_format,
  unit_price,
  quantity,
  created_at,
  seller:users!order_items_seller_id_fkey (
    id,
    profile:profiles ( username, display_name, avatar_url )
  )
`

const PAID_ORDER_STATUSES: OrderStatus[] = ['PAYMENT_CONFIRMED', 'PROCESSING', 'SHIPPED', 'FULFILLED', 'COMPLETED']

function toUnfulfilledEntry(
  item: any,
  order: UnfulfilledOrderRow,
  paymentStatus: TransactionStatus | null,
): OrderItemPhysicalListEntry {
  const isDigital = item['artwork_format'] === 'DIGITAL'
  const closed    = order.status === 'CANCELLED' || order.status === 'REFUNDED'
  const delivery_status: DeliveryStatus =
    closed                                                  ? 'CANCELLED' :
    isDigital && PAID_ORDER_STATUSES.includes(order.status) ? 'DELIVERED' :
    'LIVE'
  const createdAt   = new Date(item['created_at'])
  // When the order was closed, `cancelled_at` is that moment; older rows fall back to updated_at.
  const cancelledAt = closed ? new Date(order.cancelled_at ?? order.updated_at) : null

  return {
    id:                      item['id'],
    order_item_id:           item['id'],
    order_id:                item['order_id'],
    timeline_status:         'ORDER_RECEIVED',
    delivery_status,
    shipping_cost:           null,
    courier_name:            null,
    courier_service_type:    null,
    tracking_id:             null,
    estimated_delivery_date: null,
    pickup_address:          null,
    refund_status:           'NONE',
    refund_amount:           null,
    refund_initiated_at:     null,
    refund_completed_at:     null,
    refund_notes:            null,
    confirmed_at:            null,
    picked_up_at:            null,
    in_transit_at:           null,
    delivered_at:            null,
    created_at:              createdAt,
    updated_at:              cancelledAt ?? new Date(order.updated_at),
    order_number:            order.order_number ?? null,
    order_item: {
      artwork_id:            item['artwork_id'] ?? '',
      artwork_title:         item['artwork_title'] ?? 'Untitled artwork',
      artwork_slug:          item['artwork_slug'] ?? '',
      artwork_thumbnail_url: item['artwork_thumbnail_url'] ?? null,
      artwork_format:        item['artwork_format'] ?? 'PHYSICAL',
      unit_price:            item['unit_price'] != null ? Number(item['unit_price']) : 0,
      quantity:              item['quantity'] ?? 1,
      created_at:            createdAt,
    },
    cancelled_by:   closed ? (order.cancelled_by ?? null) : null,
    cancelled_at:   cancelledAt,
    buyer:          null,
    seller:         toPartySummary(item['seller']),
    source:         isDigital ? 'digital' : 'unfulfilled',
    order_status:   order.status,
    payment_status: paymentStatus,
  }
}

// Fills cancelled_by / cancelled_at from the timeline event that moved the
// item into a cancelled state. The list embed cannot carry this because it is
// derived from the latest matching event per item.
async function attachCancellation(
  entries: OrderItemPhysicalListEntry[],
  context: string,
): Promise<OrderItemPhysicalListEntry[]> {
  const cancelled = entries.filter(e => e.delivery_status === 'CANCELLED')
  if (!cancelled.length) return entries

  const result = await (supabase() as any)
    .from('order_timeline_events')
    .select('order_item_physical_id, actor_role, occurred_at')
    .in('order_item_physical_id', cancelled.map(e => e.id))
    .in('timeline_status', ['ORDER_FAILED_TO_CONFIRM', 'DELIVERY_FAILED'])
    .order('occurred_at', { ascending: false })

  if (result.error) {
    throw new Error(`[${context}] ${result.error.message}`)
  }

  const latest = new Map<string, { actor_role: OrderTimelineEvent['actor_role']; occurred_at: string }>()
  for (const row of result.data ?? []) {
    const id = row['order_item_physical_id'] as string
    if (!latest.has(id)) latest.set(id, { actor_role: row['actor_role'], occurred_at: row['occurred_at'] })
  }

  return entries.map(entry => {
    const hit = latest.get(entry.id)
    return hit
      ? { ...entry, cancelled_by: hit.actor_role, cancelled_at: new Date(hit.occurred_at) }
      : entry
  })
}

function escapeLikePattern(term: string): string {
  return term.replace(/[\\%_]/g, '\\$&')
}

function toTimelineEvent(row: any): OrderTimelineEvent {
  return {
    id:                     row['id'],
    order_item_physical_id: row['order_item_physical_id'],
    order_id:               row['order_id'],
    order_item_id:          row['order_item_id'],
    timeline_status:        row['timeline_status'] as TimelineStatus,
    is_pending:             row['is_pending'] as boolean,
    actor_id:               row['actor_id'] ?? null,
    actor_role:             row['actor_role'] as OrderTimelineEvent['actor_role'],
    notes:                  row['notes'] ?? null,
    metadata:               (row['metadata'] ?? {}) as Record<string, unknown>,
    occurred_at:            new Date(row['occurred_at']),
  }
}

function toDeliveryProof(row: any): DeliveryProof {
  return {
    id:                     row['id'],
    order_item_physical_id: row['order_item_physical_id'],
    order_id:               row['order_id'],
    cloudinary_public_id:   row['cloudinary_public_id'],
    secure_url:             row['secure_url'],
    mime_type:              row['mime_type'],
    file_size_bytes:        row['file_size_bytes'],
    uploaded_by:            row['uploaded_by'],
    uploader_role:          row['uploader_role'] as DeliveryProof['uploader_role'],
    uploaded_at:            new Date(row['uploaded_at']),
  }
}

function toInvoice(row: any): OrderInvoice {
  return {
    id:                       row['id'],
    order_id:                 row['order_id'],
    version:                  row['version'],
    pdf_cloudinary_public_id: row['pdf_cloudinary_public_id'],
    pdf_url:                  row['pdf_url'],
    generated_at:             new Date(row['generated_at']),
    generated_by:             row['generated_by'],
    trigger:                  row['trigger'] as OrderInvoice['trigger'],
  }
}

function toReceipt(row: any): OrderReceipt {
  return {
    id:                       row['id'],
    order_id:                 row['order_id'],
    pdf_cloudinary_public_id: row['pdf_cloudinary_public_id'],
    pdf_url:                  row['pdf_url'],
    amount_paid:              Number(row['amount_paid']),
    currency:                 row['currency'],
    payment_method:           row['payment_method'],
    transaction_reference:    row['transaction_reference'] ?? null,
    generated_at:             new Date(row['generated_at']),
    generated_by:             row['generated_by'],
  }
}

function toRefundRequest(row: any): RefundRequest {
  return {
    id:                     row['id'],
    order_item_physical_id: row['order_item_physical_id'],
    order_id:               row['order_id'],
    requested_by:           row['requested_by'],
    reason:                 row['reason'],
    status:                 row['status'] as RefundRequest['status'],
    admin_notes:            row['admin_notes'] ?? null,
    reviewed_by:            row['reviewed_by'] ?? null,
    reviewed_at:            row['reviewed_at'] ? new Date(row['reviewed_at']) : null,
    created_at:             new Date(row['created_at']),
  }
}

// ── Repository ────────────────────────────────────────────────────────────────

export const physicalOrderRepository = {

  // ── assignOrderNumber ───────────────────────────────────────────────────────
  // Calls the DB RPC which generates a collision-safe AR-XXXXXXXX number
  // and sets it atomically. Idempotent — safe to call multiple times.

  async assignOrderNumber(orderId: string): Promise<string> {
    const result = await (supabase() as any)
      .rpc('assign_order_number', { p_order_id: orderId })

    if (result.error) {
      throw new Error(`[physical:assignOrderNumber] ${result.error.message}`)
    }
    return result.data as string
  },

  // ── getOrderNumber ──────────────────────────────────────────────────────────

  async getOrderNumber(orderId: string): Promise<string | null> {
    const result = await (supabase() as any)
      .from('orders')
      .select('order_number')
      .eq('id', orderId)
      .single()

    if (result.error) return null
    return (result.data?.['order_number'] as string | null) ?? null
  },

  // ── createPhysicalItems ─────────────────────────────────────────────────────
  // Called after payment confirms. One row per physical order_item.
  // Also appends the initial ORDER_RECEIVED timeline event via the RPC.

  async createPhysicalItems(inputs: Array<{
    order_item_id: string
    order_id:      string
  }>): Promise<OrderItemPhysical[]> {
    if (inputs.length === 0) return []

    const rows = inputs.map(i => ({
      order_item_id:   i.order_item_id,
      order_id:        i.order_id,
      timeline_status: 'ORDER_RECEIVED',
      delivery_status: 'LIVE',
      refund_status:   'NONE',
    }))

    const result = await (supabase() as any)
      .from('order_item_physical')
      .insert(rows)
      .select('*')

    assertNoErrorMany(result, 'physical.createPhysicalItems')
    const created = (result.data ?? []).map(toPhysical)

    // Append initial ORDER_RECEIVED event for each item
    await Promise.all(
      created.map((item: OrderItemPhysical) =>
        this.transitionStatus({
          physicalId: item.id,
          newStatus:  'ORDER_RECEIVED',
          isPending:  false,
          actorId:    null,
          actorRole:  'system',
          notes:      'Order received after payment confirmed',
          metadata:   {},
        }),
      ),
    )

    return created
  },

  // ── transitionStatus ───────────────────────────────────────────────────────
  // Calls the atomic DB RPC that locks the row, updates timeline_status,
  // derives delivery_status, sets milestone timestamps, and appends the
  // timeline event — all in one transaction.

  async transitionStatus(input: {
    physicalId: string
    newStatus:  TimelineStatus
    isPending:  boolean
    actorId:    string | null
    actorRole:  OrderTimelineEvent['actor_role']
    notes:      string | null
    metadata:   Record<string, unknown>
  }): Promise<{ physical: OrderItemPhysical; eventId: string }> {
    const rpcResult = await (supabase() as any)
      .rpc('transition_item_timeline', {
        p_physical_id: input.physicalId,
        p_new_status:  input.newStatus,
        p_is_pending:  input.isPending,
        p_actor_id:    input.actorId,
        p_actor_role:  input.actorRole,
        p_notes:       input.notes,
        p_metadata:    input.metadata,
      })

    if (rpcResult.error) {
      throw new Error(`[physical:transitionStatus] ${rpcResult.error.message}`)
    }

    const eventId = rpcResult.data as string

    // Re-fetch the updated physical row
    const physResult = await (supabase() as any)
      .from('order_item_physical')
      .select('*')
      .eq('id', input.physicalId)
      .single()

    assertNoError(physResult, 'physical.transitionStatus.refetch')
    return { physical: toPhysical(physResult.data), eventId }
  },

  // ── findById ────────────────────────────────────────────────────────────────
  // Lookup by the order_item_physical primary key. This is the id the list
  // endpoints return and the id every /api/physical-orders/:physicalId route,
  // the transition RPC and the confirmation-timeout job operate on.

  async findById(physicalId: string): Promise<OrderItemPhysical | undefined> {
    const result = await (supabase() as any)
      .from('order_item_physical')
      .select('*')
      .eq('id', physicalId)
      .single()

    if (result.error?.code === 'PGRST116') return undefined
    assertNoError(result, 'physical.findById')
    return toPhysical(result.data)
  },

  // ── findByOrderItemId ───────────────────────────────────────────────────────

  async findByOrderItemId(orderItemId: string): Promise<OrderItemPhysical | undefined> {
    const result = await (supabase() as any)
      .from('order_item_physical')
      .select('*')
      .eq('order_item_id', orderItemId)
      .single()

    if (result.error?.code === 'PGRST116') return undefined
    assertNoError(result, 'physical.findByOrderItemId')
    return toPhysical(result.data)
  },

  // ── findByOrderId ───────────────────────────────────────────────────────────

  async findByOrderId(orderId: string): Promise<OrderItemPhysical[]> {
    const result = await (supabase() as any)
      .from('order_item_physical')
      .select('*')
      .eq('order_id', orderId)
      .order('created_at', { ascending: true })

    assertNoErrorMany(result, 'physical.findByOrderId')
    return (result.data ?? []).map(toPhysical)
  },

  // ── updateCourierInfo ───────────────────────────────────────────────────────
  // Admin-only PATCH for courier name, type, and tracking ID.

  async updateCourierInfo(
    physicalId: string,
    patch: Partial<{
      courier_name:           string
      courier_service_type:   CourierServiceType
      tracking_id:            string
      shipping_cost:          number
      estimated_delivery_date:string   // ISO date string YYYY-MM-DD
      pickup_address:         string
    }>,
  ): Promise<OrderItemPhysical> {
    const payload: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    }
    if (patch.courier_name           !== undefined) payload['courier_name']            = patch.courier_name
    if (patch.courier_service_type   !== undefined) payload['courier_service_type']    = patch.courier_service_type
    if (patch.tracking_id            !== undefined) payload['tracking_id']             = patch.tracking_id
    if (patch.shipping_cost          !== undefined) payload['shipping_cost']           = patch.shipping_cost
    if (patch.estimated_delivery_date !== undefined) payload['estimated_delivery_date'] = patch.estimated_delivery_date
    if (patch.pickup_address         !== undefined) payload['pickup_address']          = patch.pickup_address

    const result = await (supabase() as any)
      .from('order_item_physical')
      .update(payload)
      .eq('id', physicalId)
      .select('*')
      .single()

    assertNoError(result, 'physical.updateCourierInfo')
    return toPhysical(result.data)
  },

  // ── updateRefundState ───────────────────────────────────────────────────────

  async updateRefundState(
    physicalId: string,
    patch: {
      refund_status:       RefundStatus
      refund_amount?:      number
      refund_initiated_at?: Date
      refund_completed_at?: Date
      refund_notes?:       string
    },
  ): Promise<OrderItemPhysical> {
    const payload: Record<string, unknown> = {
      refund_status: patch.refund_status,
      updated_at:    new Date().toISOString(),
    }
    if (patch.refund_amount      !== undefined) payload['refund_amount']      = patch.refund_amount
    if (patch.refund_initiated_at !== undefined) payload['refund_initiated_at'] = patch.refund_initiated_at.toISOString()
    if (patch.refund_completed_at !== undefined) payload['refund_completed_at'] = patch.refund_completed_at.toISOString()
    if (patch.refund_notes       !== undefined) payload['refund_notes']       = patch.refund_notes

    const result = await (supabase() as any)
      .from('order_item_physical')
      .update(payload)
      .eq('id', physicalId)
      .select('*')
      .single()

    assertNoError(result, 'physical.updateRefundState')
    return toPhysical(result.data)
  },

  // ── getTimeline ─────────────────────────────────────────────────────────────

  async getTimeline(physicalId: string): Promise<OrderTimelineEvent[]> {
    const result = await (supabase() as any)
      .from('order_timeline_events')
      .select('*')
      .eq('order_item_physical_id', physicalId)
      .order('occurred_at', { ascending: true })

    assertNoErrorMany(result, 'physical.getTimeline')
    return (result.data ?? []).map(toTimelineEvent)
  },

  // ── getTimelineForOrder ─────────────────────────────────────────────────────

  async getTimelineForOrder(orderId: string): Promise<OrderTimelineEvent[]> {
    const result = await (supabase() as any)
      .from('order_timeline_events')
      .select('*')
      .eq('order_id', orderId)
      .order('occurred_at', { ascending: true })

    assertNoErrorMany(result, 'physical.getTimelineForOrder')
    return (result.data ?? []).map(toTimelineEvent)
  },

  // ── addDeliveryProof ────────────────────────────────────────────────────────

  async addDeliveryProof(input: {
    order_item_physical_id: string
    order_id:               string
    cloudinary_public_id:   string
    secure_url:             string
    mime_type:              string
    file_size_bytes:        number
    uploaded_by:            string
    uploader_role:          DeliveryProof['uploader_role']
  }): Promise<DeliveryProof> {
    // Enforce max 5 proofs per item at the application layer
    const countResult = await (supabase() as any)
      .from('order_delivery_proofs')
      .select('id', { count: 'exact', head: true })
      .eq('order_item_physical_id', input.order_item_physical_id)

    if ((countResult.count ?? 0) >= 5) {
      throw new Error('physical.addDeliveryProof: maximum of 5 proofs already uploaded for this item')
    }

    const result = await (supabase() as any)
      .from('order_delivery_proofs')
      .insert({
        order_item_physical_id: input.order_item_physical_id,
        order_id:               input.order_id,
        cloudinary_public_id:   input.cloudinary_public_id,
        secure_url:             input.secure_url,
        mime_type:              input.mime_type,
        file_size_bytes:        input.file_size_bytes,
        uploaded_by:            input.uploaded_by,
        uploader_role:          input.uploader_role,
      })
      .select('*')
      .single()

    assertNoError(result, 'physical.addDeliveryProof')
    return toDeliveryProof(result.data)
  },

  // ── getDeliveryProofs ───────────────────────────────────────────────────────

  async getDeliveryProofs(physicalId: string): Promise<DeliveryProof[]> {
    const result = await (supabase() as any)
      .from('order_delivery_proofs')
      .select('*')
      .eq('order_item_physical_id', physicalId)
      .order('uploaded_at', { ascending: true })

    assertNoErrorMany(result, 'physical.getDeliveryProofs')
    return (result.data ?? []).map(toDeliveryProof)
  },

  // ── upsertInvoice ───────────────────────────────────────────────────────────
  // Creates a new invoice version. Version is always max(existing) + 1.

  async upsertInvoice(input: {
    order_id:                 string
    pdf_cloudinary_public_id: string
    pdf_url:                  string
    generated_by:             string
    trigger:                  OrderInvoice['trigger']
  }): Promise<OrderInvoice> {
    // Get current max version
    const maxResult = await (supabase() as any)
      .from('order_invoices')
      .select('version')
      .eq('order_id', input.order_id)
      .order('version', { ascending: false })
      .limit(1)
      .maybeSingle()

    const nextVersion = maxResult.data ? (maxResult.data['version'] as number) + 1 : 1

    const result = await (supabase() as any)
      .from('order_invoices')
      .insert({
        order_id:                 input.order_id,
        version:                  nextVersion,
        pdf_cloudinary_public_id: input.pdf_cloudinary_public_id,
        pdf_url:                  input.pdf_url,
        generated_by:             input.generated_by,
        trigger:                  input.trigger,
      })
      .select('*')
      .single()

    assertNoError(result, 'physical.upsertInvoice')
    return toInvoice(result.data)
  },

  // ── getLatestInvoice ────────────────────────────────────────────────────────

  async getLatestInvoice(orderId: string): Promise<OrderInvoice | null> {
    const result = await (supabase() as any)
      .from('order_invoices')
      .select('*')
      .eq('order_id', orderId)
      .order('version', { ascending: false })
      .limit(1)
      .maybeSingle()

    if (!result.data) return null
    return toInvoice(result.data)
  },

  // ── createReceipt ───────────────────────────────────────────────────────────
  // Issued exactly once per order at payment confirmation. Unlike invoices,
  // a receipt documents the payment event itself and is never re-versioned —
  // attempting to create a second receipt for the same order is a no-op
  // that returns the existing one (idempotent, mirrors assignOrderNumber).

  async createReceipt(input: {
    order_id:                 string
    pdf_cloudinary_public_id: string
    pdf_url:                  string
    amount_paid:              number
    currency:                 string
    payment_method:           string
    transaction_reference:    string | null
    generated_by:             string
  }): Promise<OrderReceipt> {
    const existing = await this.getReceipt(input.order_id)
    if (existing) return existing

    const result = await (supabase() as any)
      .from('order_receipts')
      .insert({
        order_id:                 input.order_id,
        pdf_cloudinary_public_id: input.pdf_cloudinary_public_id,
        pdf_url:                  input.pdf_url,
        amount_paid:              input.amount_paid,
        currency:                 input.currency,
        payment_method:           input.payment_method,
        transaction_reference:    input.transaction_reference,
        generated_by:             input.generated_by,
      })
      .select('*')
      .single()

    // Unique constraint race: another request created it first — fetch and return.
    if (result.error?.code === '23505') {
      const fallback = await this.getReceipt(input.order_id)
      if (fallback) return fallback
    }

    assertNoError(result, 'physical.createReceipt')
    return toReceipt(result.data)
  },

  // ── getReceipt ──────────────────────────────────────────────────────────────

  async getReceipt(orderId: string): Promise<OrderReceipt | null> {
    const result = await (supabase() as any)
      .from('order_receipts')
      .select('*')
      .eq('order_id', orderId)
      .maybeSingle()

    if (!result.data) return null
    return toReceipt(result.data)
  },

  // ── createRefundRequest ─────────────────────────────────────────────────────

  async createRefundRequest(input: {
    order_item_physical_id: string
    order_id:               string
    requested_by:           string
    reason:                 string
  }): Promise<RefundRequest> {
    // Only one pending request per physical item at a time
    const existing = await (supabase() as any)
      .from('order_refund_requests')
      .select('id')
      .eq('order_item_physical_id', input.order_item_physical_id)
      .eq('status', 'PENDING_ADMIN')
      .maybeSingle()

    if (existing.data) {
      throw new Error('physical.createRefundRequest: a pending refund request already exists for this item')
    }

    const result = await (supabase() as any)
      .from('order_refund_requests')
      .insert({
        order_item_physical_id: input.order_item_physical_id,
        order_id:               input.order_id,
        requested_by:           input.requested_by,
        reason:                 input.reason,
        status:                 'PENDING_ADMIN',
      })
      .select('*')
      .single()

    assertNoError(result, 'physical.createRefundRequest')
    return toRefundRequest(result.data)
  },

  // ── updateRefundRequest ─────────────────────────────────────────────────────

  async updateRefundRequest(
    requestId: string,
    patch: {
      status:       RefundRequest['status']
      admin_notes?: string
      reviewed_by:  string
    },
  ): Promise<RefundRequest> {
    const result = await (supabase() as any)
      .from('order_refund_requests')
      .update({
        status:       patch.status,
        admin_notes:  patch.admin_notes ?? null,
        reviewed_by:  patch.reviewed_by,
        reviewed_at:  new Date().toISOString(),
      })
      .eq('id', requestId)
      .select('*')
      .single()

    assertNoError(result, 'physical.updateRefundRequest')
    return toRefundRequest(result.data)
  },

  // ── getRefundRequests ───────────────────────────────────────────────────────

  async getRefundRequests(orderId: string): Promise<RefundRequest[]> {
    const result = await (supabase() as any)
      .from('order_refund_requests')
      .select('*')
      .eq('order_id', orderId)
      .order('created_at', { ascending: false })

    assertNoErrorMany(result, 'physical.getRefundRequests')
    return (result.data ?? []).map(toRefundRequest)
  },

  // ── findPendingRefundRequests ───────────────────────────────────────────────
  // Used by admin list view.

  async findPendingRefundRequests(): Promise<RefundRequest[]> {
    const result = await (supabase() as any)
      .from('order_refund_requests')
      .select('*')
      .eq('status', 'PENDING_ADMIN')
      .order('created_at', { ascending: true })

    assertNoErrorMany(result, 'physical.findPendingRefundRequests')
    return (result.data ?? []).map(toRefundRequest)
  },

  // ── findPhysicalItemsAwaitingConfirmation ───────────────────────────────────
  // Used by the auto-cancel job. Returns items that have been in
  // AWAITING_CONFIRMATION/_ACTIVE for longer than the grace period.

  async findPhysicalItemsAwaitingConfirmation(olderThanDate: Date): Promise<OrderItemPhysical[]> {
    const result = await (supabase() as any)
      .from('order_item_physical')
      .select('*')
      .in('timeline_status', ['AWAITING_CONFIRMATION', 'AWAITING_CONFIRMATION_ACTIVE'])
      .lt('updated_at', olderThanDate.toISOString())

    assertNoErrorMany(result, 'physical.findItemsAwaitingConfirmation')
    return (result.data ?? []).map(toPhysical)
  },

  // ── findAllAdminList ────────────────────────────────────────────────────────
  // Paginated admin view — all physical order items with filters.
  // artist_id/buyer_id/order_number require resolving to order_item_id /
  // order_id sets first since order_item_physical does not carry those
  // columns directly (it only references order_item_id and order_id).

  async findAllAdminList(filters: PhysicalOrderFilters): Promise<{
    data: OrderItemPhysicalListEntry[]
    total: number
    page: number
    limit: number
    total_pages: number
    has_next: boolean
    has_prev: boolean
  }> {
    const page  = Math.max(1, filters.page  ?? 1)
    const limit = Math.min(50, Math.max(1, filters.limit ?? 20))
    const from  = (page - 1) * limit
    const to    = from + limit - 1

    // ── Pre-resolve artist_id → order_item_id[] ─────────────────────────────
    let scopedOrderItemIds: string[] | null = null
    if (filters.artist_id) {
      const itemsResult = await (supabase() as any)
        .from('order_items')
        .select('id')
        .eq('seller_id', filters.artist_id)

      if (itemsResult.error) {
        throw new Error(`[physical.findAllAdminList.artist_id] ${itemsResult.error.message}`)
      }
      const resolvedItemIds: string[] = (itemsResult.data ?? []).map((r: any) => r['id'] as string)
      if (!resolvedItemIds.length) {
        return { data: [], total: 0, page, limit, total_pages: 0, has_next: false, has_prev: false }
      }
      scopedOrderItemIds = resolvedItemIds
    }

    // ── Pre-resolve buyer_id / order_number → order_id[] ─────────────────────
    let scopedOrderIds: string[] | null = null
    if (filters.buyer_id || filters.order_number) {
      let ordersQuery = (supabase() as any).from('orders').select('id')
      if (filters.buyer_id)     ordersQuery = ordersQuery.eq('buyer_id', filters.buyer_id)
      if (filters.order_number) ordersQuery = ordersQuery.ilike('order_number', filters.order_number)

      const ordersResult = await ordersQuery
      if (ordersResult.error) {
        throw new Error(`[physical.findAllAdminList.buyer_or_number] ${ordersResult.error.message}`)
      }
      const resolvedOrderIds: string[] = (ordersResult.data ?? []).map((r: any) => r['id'] as string)
      if (!resolvedOrderIds.length) {
        return { data: [], total: 0, page, limit, total_pages: 0, has_next: false, has_prev: false }
      }
      scopedOrderIds = resolvedOrderIds
    }

    let query = (supabase() as any)
      .from('order_item_physical')
      .select(PHYSICAL_LIST_EMBED, { count: 'exact' })

    if (scopedOrderItemIds)         query = query.in('order_item_id', scopedOrderItemIds)
    if (scopedOrderIds)             query = query.in('order_id', scopedOrderIds)
    if (filters.delivery_status)    query = query.eq('delivery_status', filters.delivery_status)
    if (filters.timeline_status)    query = query.eq('timeline_status', filters.timeline_status)
    if (filters.timeline_status_in) query = query.in('timeline_status', filters.timeline_status_in)
    if (filters.refund_status)      query = query.eq('refund_status', filters.refund_status)
    if (filters.courier_name)       query = query.ilike('courier_name', `%${filters.courier_name}%`)
    if (filters.tracking_id)        query = query.eq('tracking_id', filters.tracking_id)
    if (filters.date_from)          query = query.gte('created_at', filters.date_from)
    if (filters.date_to)            query = query.lte('created_at', filters.date_to)

    query = query
      .order('created_at', { ascending: filters.sort_order === 'asc' })
      .range(from, to)

    const result = await query
    if (result.error) {
      throw new Error(`[physical.findAllAdminList] ${result.error.message}`)
    }

    const total       = result.count ?? 0
    const total_pages = Math.ceil(total / limit)

    return {
      data:        (result.data ?? []).map(toPhysicalListEntry),
      total,
      page,
      limit,
      total_pages,
      has_next:    page < total_pages,
      has_prev:    page > 1,
    }
  },

  // ── findBySellerWithItems ───────────────────────────────────────────────────
  // Artist sees only their physical items (joined to order_items.seller_id).

  async findBySellerWithItems(
    sellerId: string,
    filters: PhysicalOrderFilters,
  ): Promise<{
    data: OrderItemPhysicalListEntry[]
    total: number
    page: number
    limit: number
    total_pages: number
    has_next: boolean
    has_prev: boolean
  }> {
    const page  = Math.max(1, filters.page  ?? 1)
    const limit = Math.min(50, Math.max(1, filters.limit ?? 20))
    const from  = (page - 1) * limit
    const to    = from + limit - 1

    // First get the order_item_ids belonging to this seller
    const itemsResult = await (supabase() as any)
      .from('order_items')
      .select('id')
      .eq('seller_id', sellerId)
      .eq('artwork_format', 'PHYSICAL')

    if (itemsResult.error) {
      throw new Error(`[physical.findBySeller] ${itemsResult.error.message}`)
    }

    const sellerItemIds: string[] = (itemsResult.data ?? []).map((r: any) => r['id'] as string)
    if (!sellerItemIds.length) {
      return { data: [], total: 0, page, limit, total_pages: 0, has_next: false, has_prev: false }
    }

    let query = (supabase() as any)
      .from('order_item_physical')
      .select(PHYSICAL_LIST_EMBED, { count: 'exact' })
      .in('order_item_id', sellerItemIds)

    if (filters.delivery_status)    query = query.eq('delivery_status', filters.delivery_status)
    if (filters.timeline_status)    query = query.eq('timeline_status', filters.timeline_status)
    if (filters.timeline_status_in) query = query.in('timeline_status', filters.timeline_status_in)
    if (filters.refund_status)      query = query.eq('refund_status', filters.refund_status)
    if (filters.date_from)          query = query.gte('created_at', filters.date_from)
    if (filters.date_to)            query = query.lte('created_at', filters.date_to)

    query = query
      .order('created_at', { ascending: filters.sort_order === 'asc' })
      .range(from, to)

    const result = await query
    if (result.error) {
      throw new Error(`[physical.findBySeller] ${result.error.message}`)
    }

    const total       = result.count ?? 0
    const total_pages = Math.ceil(total / limit)

    return {
      data:        (result.data ?? []).map(toPhysicalListEntry),
      total,
      page,
      limit,
      total_pages,
      has_next:    page < total_pages,
      has_prev:    page > 1,
    }
  },

  // ── findByBuyerWithItems ────────────────────────────────────────────────────
  // Buyer sees physical items for all their orders.

  async findByBuyerWithItems(
    buyerId: string,
    filters: PhysicalOrderFilters,
  ): Promise<{
    data: OrderItemPhysicalListEntry[]
    total: number
    page: number
    limit: number
    total_pages: number
    has_next: boolean
    has_prev: boolean
  }> {
    const page  = Math.max(1, filters.page  ?? 1)
    const limit = Math.min(50, Math.max(1, filters.limit ?? 20))
    const from  = (page - 1) * limit
    const to    = from + limit - 1
    const empty = { data: [], total: 0, page, limit, total_pages: 0, has_next: false, has_prev: false }

    // Get order IDs belonging to this buyer
    const ordersResult = await (supabase() as any)
      .from('orders')
      .select('id, order_number')
      .eq('buyer_id', buyerId)

    if (ordersResult.error) {
      throw new Error(`[physical.findByBuyer] ${ordersResult.error.message}`)
    }

    const buyerOrders: Array<{ id: string; order_number: string | null }> = ordersResult.data ?? []
    if (!buyerOrders.length) return empty
    const buyerOrderIds = buyerOrders.map(o => o.id)

    // Search matches the artwork title or the order number. Both resolve to
    // order_item ids, which are then intersected with the physical rows.
    let searchItemIds: string[] | null = null
    const term = filters.search?.trim()
    if (term) {
      const pattern     = `%${escapeLikePattern(term)}%`
      const numberMatch = buyerOrders
        .filter(o => o.order_number && o.order_number.toLowerCase().includes(term.toLowerCase()))
        .map(o => o.id)

      const [byTitle, byNumber] = await Promise.all([
        (supabase() as any)
          .from('order_items')
          .select('id')
          .in('order_id', buyerOrderIds)
          .ilike('artwork_title', pattern),
        numberMatch.length
          ? (supabase() as any).from('order_items').select('id').in('order_id', numberMatch)
          : Promise.resolve({ data: [], error: null }),
      ])

      if (byTitle.error)  throw new Error(`[physical.findByBuyer.search] ${byTitle.error.message}`)
      if (byNumber.error) throw new Error(`[physical.findByBuyer.search] ${byNumber.error.message}`)

      searchItemIds = [...new Set<string>([...(byTitle.data ?? []), ...(byNumber.data ?? [])].map((r: any) => r['id'] as string))]
      if (!searchItemIds.length) return empty
    }

    const applyFilters = (query: any) => {
      let q = query.in('order_id', buyerOrderIds)
      if (searchItemIds)              q = q.in('order_item_id', searchItemIds)
      if (filters.delivery_status)    q = q.eq('delivery_status', filters.delivery_status)
      if (filters.timeline_status)    q = q.eq('timeline_status', filters.timeline_status)
      if (filters.timeline_status_in) q = q.in('timeline_status', filters.timeline_status_in)
      if (filters.date_from)          q = q.gte('created_at', filters.date_from)
      if (filters.date_to)            q = q.lte('created_at', filters.date_to)
      return q
    }

    const ascending = filters.sort_order === 'asc'
    let rows: any[]
    let total: number

    if (filters.sort_by === 'value') {
      // Value is unit_price * quantity + shipping_cost, which spans two tables
      // and cannot be expressed as an ORDER BY through PostgREST. Rank the
      // buyer's matching items on a minimal projection, then load only the
      // requested page with the full embed.
      const rankResult = await applyFilters(
        (supabase() as any)
          .from('order_item_physical')
          .select(`
            id,
            created_at,
            shipping_cost,
            order_item:order_items!order_item_physical_order_item_id_fkey ( unit_price, quantity )
          `),
      )

      if (rankResult.error) {
        throw new Error(`[physical.findByBuyer.rank] ${rankResult.error.message}`)
      }

      const ranked = (rankResult.data ?? []).map((row: any) => {
        const item = Array.isArray(row.order_item) ? row.order_item[0] : row.order_item
        const value = Number(item?.unit_price ?? 0) * Number(item?.quantity ?? 1) + Number(row.shipping_cost ?? 0)
        return { id: row.id as string, value, created_at: new Date(row.created_at).getTime() }
      })
      ranked.sort((a: any, b: any) => (ascending ? a.value - b.value : b.value - a.value) || b.created_at - a.created_at)

      total = ranked.length
      const pageIds = ranked.slice(from, to + 1).map((r: any) => r.id)
      if (!pageIds.length) {
        rows = []
      } else {
        const pageResult = await (supabase() as any)
          .from('order_item_physical')
          .select(PHYSICAL_LIST_EMBED)
          .in('id', pageIds)

        if (pageResult.error) {
          throw new Error(`[physical.findByBuyer] ${pageResult.error.message}`)
        }
        const byId = new Map<string, any>((pageResult.data ?? []).map((r: any) => [r.id, r]))
        rows = pageIds.map((id: string) => byId.get(id)).filter(Boolean)
      }
    } else {
      const result = await applyFilters(
        (supabase() as any)
          .from('order_item_physical')
          .select(PHYSICAL_LIST_EMBED, { count: 'exact' }),
      )
        .order('created_at', { ascending })
        .range(from, to)

      if (result.error) {
        throw new Error(`[physical.findByBuyer] ${result.error.message}`)
      }
      rows  = result.data ?? []
      total = result.count ?? 0
    }

    const total_pages = Math.ceil(total / limit)
    const data = await attachCancellation(rows.map(toPhysicalListEntry), 'physical.findByBuyer.cancellation')

    return {
      data,
      total,
      page,
      limit,
      total_pages,
      has_next:    page < total_pages,
      has_prev:    page > 1,
    }
  },

  // ── findBuyerItemsWithoutPhysicalRow ─────────────────────────────────────────
  // order_item_physical rows only exist once payment is confirmed (and only for
  // physical items), so a buyer's "My Orders" built from that table alone hides
  // unpaid orders, expired/cancelled orders and every digital purchase. This
  // returns those order items as list entries so the buyer can see them.
  // Entries use the order_item id as `id` and carry source/order_status/
  // payment_status so the UI can render them without a physical-order detail.

  async findBuyerItemsWithoutPhysicalRow(buyerId: string): Promise<OrderItemPhysicalListEntry[]> {
    const ordersResult = await (supabase() as any)
      .from('orders')
      .select(UNFULFILLED_ORDER_COLUMNS)
      .eq('buyer_id', buyerId)

    if (ordersResult.error) {
      throw new Error(`[physical.findBuyerUnfulfilled.orders] ${ordersResult.error.message}`)
    }

    const orders: UnfulfilledOrderRow[] = ordersResult.data ?? []
    if (!orders.length) return []
    const orderById = new Map(orders.map(o => [o.id, o]))
    const orderIds  = orders.map(o => o.id)

    const itemsResult = await (supabase() as any)
      .from('order_items')
      .select(UNFULFILLED_ITEM_COLUMNS)
      .in('order_id', orderIds)

    if (itemsResult.error) {
      throw new Error(`[physical.findBuyerUnfulfilled.items] ${itemsResult.error.message}`)
    }

    const items: any[] = itemsResult.data ?? []
    if (!items.length) return []
    const itemIds = items.map(i => i['id'] as string)

    const [physicalResult, txResult] = await Promise.all([
      (supabase() as any).from('order_item_physical').select('order_item_id').in('order_item_id', itemIds),
      (supabase() as any)
        .from('transactions')
        .select('order_id, status, created_at')
        .in('order_id', orderIds)
        .order('created_at', { ascending: false }),
    ])

    if (physicalResult.error) {
      throw new Error(`[physical.findBuyerUnfulfilled.physical] ${physicalResult.error.message}`)
    }
    if (txResult.error) {
      throw new Error(`[physical.findBuyerUnfulfilled.transactions] ${txResult.error.message}`)
    }

    const hasPhysical = new Set<string>((physicalResult.data ?? []).map((r: any) => r['order_item_id'] as string))

    // Newest transaction per order wins (rows arrive newest-first).
    const paymentStatusByOrder = new Map<string, TransactionStatus>()
    for (const tx of txResult.data ?? []) {
      if (!paymentStatusByOrder.has(tx['order_id'])) paymentStatusByOrder.set(tx['order_id'], tx['status'] as TransactionStatus)
    }

    return items
      .filter(item => !hasPhysical.has(item['id']))
      .map(item => toUnfulfilledEntry(item, orderById.get(item['order_id'])!, paymentStatusByOrder.get(item['order_id']) ?? null))
  },

  // ── findUnfulfilledByOrderItemId ─────────────────────────────────────────────
  // One physical order item that has no order_item_physical row yet, as a list
  // entry plus the order's buyer id (for the access check). Returns null when the
  // id is unknown, is a digital item, or already has a real physical row.

  async findUnfulfilledByOrderItemId(
    orderItemId: string,
  ): Promise<{ entry: OrderItemPhysicalListEntry; buyer_id: string } | null> {
    const itemResult = await (supabase() as any)
      .from('order_items')
      .select(UNFULFILLED_ITEM_COLUMNS)
      .eq('id', orderItemId)
      .limit(1)

    if (itemResult.error) {
      throw new Error(`[physical.findUnfulfilledByItem.item] ${itemResult.error.message}`)
    }
    const item = (itemResult.data ?? [])[0]
    if (!item || item['artwork_format'] === 'DIGITAL') return null

    const [orderResult, physicalResult, txResult] = await Promise.all([
      (supabase() as any).from('orders').select(UNFULFILLED_ORDER_COLUMNS).eq('id', item['order_id']).limit(1),
      (supabase() as any).from('order_item_physical').select('id').eq('order_item_id', orderItemId).limit(1),
      (supabase() as any)
        .from('transactions')
        .select('status')
        .eq('order_id', item['order_id'])
        .order('created_at', { ascending: false })
        .limit(1),
    ])

    for (const [name, result] of [['order', orderResult], ['physical', physicalResult], ['transactions', txResult]] as const) {
      if (result.error) throw new Error(`[physical.findUnfulfilledByItem.${name}] ${result.error.message}`)
    }

    const order = (orderResult.data ?? [])[0] as (UnfulfilledOrderRow & { buyer_id: string }) | undefined
    if (!order || (physicalResult.data ?? []).length > 0) return null

    const paymentStatus = ((txResult.data ?? [])[0]?.['status'] ?? null) as TransactionStatus | null
    return { entry: toUnfulfilledEntry(item, order, paymentStatus), buyer_id: order.buyer_id }
  },

  // ── getOrderItem ────────────────────────────────────────────────────────────
  // The order_items snapshot (title, price, quantity, variant) for one item.

  async getOrderItem(orderItemId: string): Promise<OrderItem | null> {
    const result = await (supabase() as any)
      .from('order_items')
      .select('*')
      .eq('id', orderItemId)
      .single()

    if (result.error?.code === 'PGRST116') return null
    assertNoError(result, 'physical.getOrderItem')
    return toOrderItem(result.data)
  },

  // ── getUserProfile ──────────────────────────────────────────────────────────
  // Light profile lookup for buyer/seller embedding in order views.

  async getUserProfile(userId: string): Promise<{ id: string; username: string; avatar_url: string | null } | null> {
    const result = await (supabase() as any)
      .from('users')
      .select('id, username, avatar_url')
      .eq('id', userId)
      .single()

    if (result.error) return null
    return {
      id:         result.data['id'] as string,
      username:   result.data['username'] as string,
      avatar_url: (result.data['avatar_url'] as string | null) ?? null,
    }
  },

  // ── findAllAdmins ───────────────────────────────────────────────────────────
  // Returns user IDs of all ADMIN users for bulk notification.

  async findAllAdminIds(): Promise<string[]> {
    const result = await (supabase() as any)
      .from('users')
      .select('id')
      .eq('role', 'ADMIN')
      .eq('status', 'ACTIVE')
      .is('deleted_at', null)

    if (result.error) return []
    return (result.data ?? []).map((r: any) => r['id'] as string)
  },

  // ── getShippingAddress ──────────────────────────────────────────────────────
  // Delivery address lives on orders.shipping_address (immutable snapshot,
  // see order.repository.ts). Exposed here so physical order views can embed
  // it without the caller needing to know about the base orders table.

  async getShippingAddress(orderId: string): Promise<{
    full_name: string
    phone: string
    address_line_1: string
    address_line_2: string | null
    city: string
    state: string
    postal_code: string
    country_code: string
  } | null> {
    const result = await (supabase() as any)
      .from('orders')
      .select('shipping_address')
      .eq('id', orderId)
      .single()

    if (result.error || !result.data?.['shipping_address']) return null
    return result.data['shipping_address']
  },
}