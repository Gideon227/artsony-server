import 'dotenv/config'

function require_env(key: string): string {
  const value = process.env[key]
  if (!value) throw new Error(`Missing required environment variable: ${key}`)
  return value
}

function optional_env(key: string, fallback: string): string {
  return process.env[key] ?? fallback
}

// ── Environment Constants (Fixes noPropertyAccessFromIndexSignature) ─────────
const currentEnv = (process.env['NODE_ENV'] ?? 'development') as 'development' | 'production' | 'test'
const isProduction = currentEnv === 'production'

export const config = {
  env: currentEnv,
  port: parseInt(optional_env('PORT', '4000'), 10),

  // ── Supabase (replaces raw DB connection config) ─────────────────────────
  // SUPABASE_URL:              from Project Settings → API → Project URL
  // SUPABASE_SERVICE_ROLE_KEY: from Project Settings → API → service_role secret
  //                            ⚠ Never expose this to the client/browser
  supabase: {
    url: require_env('SUPABASE_URL'),
    serviceRoleKey: require_env('SUPABASE_SERVICE_ROLE_KEY'),
    // The anon key is only needed if you run any client-side Supabase calls
    anonKey: optional_env('SUPABASE_ANON_KEY', ''),
  },

  redis: {
    url: require_env('REDIS_URL'),
    keyPrefix: 'artsony:',
  },

  jwt: {
    privateKey: require_env('JWT_PRIVATE_KEY').replace(/\\n/g, '\n'),
    publicKey: require_env('JWT_PUBLIC_KEY').replace(/\\n/g, '\n'),
    accessTokenTtl: 15 * 60,
    // Sliding window: sessionRepository.rotate() extends this on every
    // successful refresh, so an active user is never forced to log back in.
    // A session only actually expires after this long of *no* activity at all.
    refreshTokenTtl: 90 * 24 * 60 * 60, // 3 months
    issuer: 'artsony',
    audience: 'artsony-client',
  },

  cookie: {
    domain: optional_env('COOKIE_DOMAIN', 'localhost'),
    secure: isProduction,
    sameSite: 'strict' as const,
  },

  app: {
    frontendUrl: require_env('FRONTEND_URL'),
    apiUrl: require_env('API_URL'),
  },

  oauth: {
    google: {
      clientId: require_env('GOOGLE_CLIENT_ID'),
      clientSecret: require_env('GOOGLE_CLIENT_SECRET'),
      callbackUrl: require_env('GOOGLE_CALLBACK_URL'),
    },
    facebook: {
      appId: require_env('FACEBOOK_APP_ID'),
      appSecret: require_env('FACEBOOK_APP_SECRET'),
      callbackUrl: require_env('FACEBOOK_CALLBACK_URL'),
    },
    stateSecret: require_env('OAUTH_STATE_SECRET'),
  },

  email: {
    host: require_env('SMTP_HOST'),
    port: parseInt(optional_env('SMTP_PORT', '587'), 10),
    secure: isProduction,
    user: require_env('SMTP_USER'),
    password: require_env('SMTP_PASSWORD'),
    from: optional_env('SMTP_FROM', 'noreply@artsony.com'),
  },

  security: {
    argon2: {
      memoryCost: 65536,
      timeCost: 3,
      parallelism: 4,
    },
    loginMaxAttempts: 5,
    loginLockoutMinutes: 30,
    resetTokenExpiryMinutes: 15,
    resetMaxAttempts: 5,
    rateLimits: {
      auth: { windowMs: 15 * 60 * 1000, max: 30 },
      api: { windowMs: 60 * 1000, max: 100 },
      passwordReset: { windowMs: 60 * 60 * 1000, max: 3 },
    },
  },

  queue: {
    emailQueue: 'artsony:queue:email',
    deletionQueue: 'artsony:queue:account-deletion',
    accountDeletionGraceDays: 30,
  },

  // ── Wallet / payouts ──────────────────────────────────────────────────────
  // No PSP is wired up yet — withdrawal_requests are fulfilled manually by an
  // admin. holdPeriodDays is the "clearing" window between a physical item
  // being marked DELIVERED and its sale proceeds becoming withdrawable.
  wallet: {
    holdPeriodDays: parseInt(optional_env('WALLET_HOLD_PERIOD_DAYS', '3'), 10),
    minWithdrawalAmount: parseFloat(optional_env('WALLET_MIN_WITHDRAWAL_AMOUNT', '20')),
  },
} as const

export type Config = typeof config