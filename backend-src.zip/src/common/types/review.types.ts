export type OrderReview = {
  id: string
  order_item_id: string
  order_id: string
  artwork_id: string
  buyer_id: string
  seller_id: string
  rating: number
  comment: string | null
  condition_rating: number | null
  delivery_rating: number | null
  created_at: Date
  updated_at: Date
}

// Denormalised view used by review listing endpoints (artist dashboard,
// artwork page) — includes just enough buyer/artwork context to render
// without a second round trip. buyer_name is the buyer's public display name
// (profiles.display_name, else a non-email username) — never their email.
export type OrderReviewWithContext = OrderReview & {
  buyer_name: string
  buyer_avatar_url: string | null
  artwork_title: string
}

export type CreateReviewInput = {
  order_item_id: string
  rating: number
  comment?: string
  condition_rating?: number
  delivery_rating?: number
}

export type ReviewFilters = {
  seller_id?: string
  artwork_id?: string
  search?: string
  date_from?: string
  date_to?: string
  page?: number
  limit?: number
  sort?: 'newest' | 'oldest' | 'highest' | 'lowest'
}
